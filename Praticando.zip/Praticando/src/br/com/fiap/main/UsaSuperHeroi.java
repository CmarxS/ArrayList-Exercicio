package br.com.fiap.main;

import br.com.fiap.bean.SuperHeroi;

import javax.swing.*;
import java.util.ArrayList;

public class UsaSuperHeroi {
    public static void main(String[] args) {
        SuperHeroi heroi;
        String nome, idSecreta;
        ArrayList<String> poderes = new ArrayList<String>();
        ArrayList<String> fraquezas = new ArrayList<String>();
        do {
            try {
                nome = JOptionPane.showInputDialog("Digite o nome do heroi");
                idSecreta = JOptionPane.showInputDialog("Digite a identidade secreta do heroi");
                do {
                    poderes.add(JOptionPane.showInputDialog("Digite o poder do heroi ou digite \"fim\" para encerrar"));
                }while (!poderes.get(poderes.size() - 1).equalsIgnoreCase("fim"));
                poderes.remove(poderes.size() - 1);
                do{
                    fraquezas.add(JOptionPane.showInputDialog("Digite a fraqueza do heroi ou digite \"fim\" para encerrar"));
                }while (!fraquezas.get(fraquezas.size() - 1).equalsIgnoreCase("fim"));
                heroi = new SuperHeroi(nome, idSecreta, poderes, fraquezas);
                heroi.listaHeroi();
                poderes.clear();
                fraquezas.clear();

            }catch (Exception e){
                JOptionPane.showMessageDialog(null, e.getMessage());
            }

        }while (JOptionPane.showConfirmDialog(null, "Deseja continuar?", "Atenção", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0);
        JOptionPane.showMessageDialog(null, "FIM DE PROGRAMA!");
    }

}
